<?php
if (!defined('ABSPATH')) exit;

class GEM_Admin {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
    }

    public function add_admin_menu() {
        add_menu_page(
            'GEM Portal',
            'GEM Portal',
            'manage_options',
            'gem-admin',
            array($this, 'render_admin_dashboard'),
            'dashicons-welcome-learn-more',
            30
        );

        // Add submenus
        $submenus = array(
            'student-management' => 'Student Management',
            'matching-process' => 'Matching Process',
            'grading-interface' => 'Grading Interface',
            'organization-management' => 'Organization Management'
        );

        foreach ($submenus as $slug => $title) {
            add_submenu_page(
                'gem-admin',
                $title,
                $title,
                'manage_options',
                'gem-' . $slug,
                array($this, 'render_' . str_replace('-', '_', $slug))
            );
        }
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'gem-') !== false) {
            wp_enqueue_style('gem-admin-styles', GEM_PLUGIN_URL . 'assets/css/core-ui.css');
            wp_enqueue_script('gem-admin-scripts', GEM_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), '1.0', true);
        }
    }

    public function render_admin_dashboard() {
        include GEM_PLUGIN_DIR . 'templates/admin/dashboard.php';
    }

    // Additional render methods for subpages
    public function render_student_management() {
        include GEM_PLUGIN_DIR . 'templates/admin/student-management.php';
    }

    public function render_matching_process() {
        include GEM_PLUGIN_DIR . 'templates/admin/matching-process.php';
    }

    public function render_grading_interface() {
        include GEM_PLUGIN_DIR . 'templates/admin/grading-interface.php';
    }

    public function render_organization_management() {
        include GEM_PLUGIN_DIR . 'templates/admin/organization-management.php';
    }
}