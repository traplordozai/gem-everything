<?php
/**
 * GEM App Admin Class
 */

defined('ABSPATH') || exit;

class GEM_App_Admin {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function init() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
    }

    public function add_admin_menu() {
        add_menu_page(
            'GEM App Dashboard',
            'GEM App',
            'manage_options',
            'gem-app-dashboard',
            array($this, 'render_dashboard_page'),
            'dashicons-groups',
            30
        );

        add_submenu_page(
            'gem-app-dashboard',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'gem-app-dashboard'
        );

        add_submenu_page(
            'gem-app-dashboard',
            'Student Management',
            'Students',
            'manage_options',
            'gem-app-students',
            array($this, 'render_students_page')
        );

        add_submenu_page(
            'gem-app-dashboard',
            'Faculty Management',
            'Faculty',
            'manage_options',
            'gem-app-faculty',
            array($this, 'render_faculty_page')
        );

        add_submenu_page(
            'gem-app-dashboard',
            'Organization Management',
            'Organizations',
            'manage_options',
            'gem-app-organizations',
            array($this, 'render_organizations_page')
        );
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'gem-app') === false) {
            return;
        }

        wp_enqueue_style(
            'gem-app-admin',
            GEM_APP_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            GEM_APP_VERSION
        );

        wp_enqueue_script(
            'gem-app-admin',
            GEM_APP_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            GEM_APP_VERSION,
            true
        );

        wp_localize_script('gem-app-admin', 'gemAppAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('gem-app-admin-nonce')
        ));
    }

    public function render_dashboard_page() {
        require_once GEM_APP_PLUGIN_DIR . 'includes/admin/views/dashboard.php';
    }

    public function render_students_page() {
        require_once GEM_APP_PLUGIN_DIR . 'includes/admin/views/students.php';
    }

    public function render_faculty_page() {
        require_once GEM_APP_PLUGIN_DIR . 'includes/admin/views/faculty.php';
    }

    public function render_organizations_page() {
        require_once GEM_APP_PLUGIN_DIR . 'includes/admin/views/organizations.php';
    }
}