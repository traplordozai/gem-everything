<?php
/**
 * API Connection for GEM App
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class to handle API connection to the GEM App microservice
 */
class GEM_App_API {
    private $api_url;
    private $access_token;
    private $refresh_token;

    /**
     * Constructor
     */
    public function __construct() {
        $this->api_url = get_option('gem_app_api_url', 'http://localhost:5000');

        // Try to get access token from user meta
        $user_id = get_current_user_id();
        if ($user_id) {
            $this->access_token = get_user_meta($user_id, 'gem_app_access_token', true);
            $this->refresh_token = get_user_meta($user_id, 'gem_app_refresh_token', true);
        }
    }

    /**
     * Check if user is authenticated with the API
     */
    public function is_authenticated() {
        return !empty($this->access_token);
    }

    /**
     * Authenticate with the API using WordPress user credentials
     */
    public function authenticate($user_id, $wp_auth_token) {
        $url = $this->api_url . '/auth/token';

        $response = wp_remote_post($url, array(
            'method' => 'POST',
            'timeout' => 45,
            'redirection' => 5,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'user_id' => $user_id,
                'wp_auth_token' => $wp_auth_token,
            )),
        ));

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message(),
            );
        }
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['status']) && $body['status'] === 'success') {
            // Store tokens in user meta
            update_user_meta($user_id, 'gem_app_access_token', $body['access_token']);
            update_user_meta($user_id, 'gem_app_refresh_token', $body['refresh_token']);
            
            $this->access_token = $body['access_token'];
            $this->refresh_token = $body['refresh_token'];
            
            return array(
                'success' => true,
                'data' => $body
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($body['message']) ? $body['message'] : 'Authentication failed'
            );
        }
    }
    
    /**
     * Refresh the access token
     */
    public function refresh_token() {
        if (empty($this->refresh_token)) {
            return array(
                'success' => false,
                'message' => 'No refresh token available'
            );
        }
        
        $url = $this->api_url . '/auth/refresh';
        
        $response = wp_remote_post($url, array(
            'method' => 'POST',
            'timeout' => 45,
            'redirection' => 5,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->refresh_token
            )
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['status']) && $body['status'] === 'success') {
            // Update access token in user meta
            $user_id = get_current_user_id();
            update_user_meta($user_id, 'gem_app_access_token', $body['access_token']);
            
            $this->access_token = $body['access_token'];
            
            return array(
                'success' => true,
                'data' => $body
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($body['message']) ? $body['message'] : 'Token refresh failed'
            );
        }
    }
    
    /**
     * Make an API request
     */
    public function request($endpoint, $method = 'GET', $data = array(), $retry = true) {
        if (empty($this->access_token) && $endpoint !== '/auth/token') {
            return array(
                'success' => false,
                'message' => 'Not authenticated'
            );
        }
        
        $url = $this->api_url . $endpoint;
        
        $args = array(
            'method' => $method,
            'timeout' => 45,
            'redirection' => 5,
            'headers' => array(
                'Content-Type' => 'application/json'
            )
        );
        
        // Add Authorization header if we have a token
        if (!empty($this->access_token)) {
            $args['headers']['Authorization'] = 'Bearer ' . $this->access_token;
        }
        
        // Add body data for POST/PUT/PATCH
        if (in_array($method, array('POST', 'PUT', 'PATCH')) && !empty($data)) {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        // Handle token expiration
        if ($status_code === 401 && $retry) {
            $refresh_result = $this->refresh_token();
            
            if ($refresh_result['success']) {
                // Retry the request with the new token
                return $this->request($endpoint, $method, $data, false);
            }
        }
        
        return array(
            'success' => $status_code >= 200 && $status_code < 300,
            'code' => $status_code,
            'data' => $body
        );
    }
    
    /**
     * Get user profile data from API
     */
    public function get_user_profile() {
        $user = wp_get_current_user();
        $roles = (array) $user->roles;
        
        if (in_array('student', $roles)) {
            return $this->request('/student/profile');
        } elseif (in_array('faculty', $roles)) {
            return $this->request('/faculty/profile');
        } elseif (in_array('organization', $roles)) {
            return $this->request('/organization/profile');
        }
        
        return array(
            'success' => false,
            'message' => 'Unknown user role'
        );
    }
    
    /**
     * Get dashboard data for current user
     */
    public function get_dashboard_data() {
        $user = wp_get_current_user();
        $roles = (array) $user->roles;
        
        if (in_array('administrator', $roles)) {
            return $this->request('/admin/dashboard');
        } elseif (in_array('student', $roles)) {
            return $this->request('/student/dashboard');
        } elseif (in_array('faculty', $roles)) {
            return $this->request('/faculty/dashboard');
        } elseif (in_array('organization', $roles)) {
            return $this->request('/organization/dashboard');
        }
        
        return array(
            'success' => false,
            'message' => 'Unknown user role'
        );
    }
}

/**
 * Get the API connection instance
 */
function gem_app_api() {
    static $instance = null;
    
    if ($instance === null) {
        $instance = new GEM_App_API();
    }
    
    return $instance;
}

/**
 * AJAX handler to authenticate with the API
 */
function gem_app_ajax_authenticate() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gem-app-nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    // Get current user
    $user_id = get_current_user_id();
    
    if ($user_id === 0) {
        wp_send_json_error('User not logged in');
    }
    
    // Generate a temporary auth token for WordPress
    $token = wp_generate_auth_cookie($user_id, time() + 3600, 'auth');
    
    // Authenticate with the API
    $api = gem_app_api();
    $result = $api->authenticate($user_id, $token);
    
    if ($result['success']) {
        wp_send_json_success($result['data']);
    } else {
        wp_send_json_error($result['message']);
    }
}
add_action('wp_ajax_gem_app_authenticate', 'gem_app_ajax_authenticate');

/**
 * Hook to authenticate user with API after login
 */
function gem_app_after_login($user_login, $user) {
    // Generate a temporary auth token for WordPress
    $token = wp_generate_auth_cookie($user->ID, time() + 3600, 'auth');
    
    // Authenticate with the API
    $api = gem_app_api();
    $api->authenticate($user->ID, $token);
}
add_action('wp_login', 'gem_app_after_login', 10, 2);