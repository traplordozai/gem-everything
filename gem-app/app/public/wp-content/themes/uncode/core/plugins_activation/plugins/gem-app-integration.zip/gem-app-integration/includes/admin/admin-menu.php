<?php
/**
 * Admin Menu Integration for GEM App
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add Admin Menu items for GEM App
 */
function gem_app_admin_menu() {
    // Main GEM App menu
    add_menu_page(
        'GEM App Admin',
        'GEM App',
        'manage_options',
        'gem-app-admin',
        'gem_app_admin_dashboard',
        'dashicons-groups',
        30
    );
    
    // Dashboard submenu
    add_submenu_page(
        'gem-app-admin',
        'Dashboard',
        'Dashboard',
        'manage_options',
        'gem-app-admin',
        'gem_app_admin_dashboard'
    );
    
    // Student Management submenu
    add_submenu_page(
        'gem-app-admin',
        'Student Management',
        'Students',
        'manage_options',
        'gem-app-students',
        'gem_app_admin_students'
    );
    
    // Organization Management submenu
    add_submenu_page(
        'gem-app-admin',
        'Organization Management',
        'Organizations',
        'manage_options',
        'gem-app-organizations',
        'gem_app_admin_organizations'
    );
    
    // Faculty Management submenu
    add_submenu_page(
        'gem-app-admin',
        'Faculty Management',
        'Faculty',
        'manage_options',
        'gem-app-faculty',
        'gem_app_admin_faculty'
    );
    
    // Matching Process submenu
    add_submenu_page(
        'gem-app-admin',
        'Matching Process',
        'Matching',
        'manage_options',
        'gem-app-matching',
        'gem_app_admin_matching'
    );
    
    // Grading Interface submenu
    add_submenu_page(
        'gem-app-admin',
        'Grading Interface',
        'Grading',
        'manage_options',
        'gem-app-grading',
        'gem_app_admin_grading'
    );
}
add_action('admin_menu', 'gem_app_admin_menu');

/**
 * Admin Dashboard page callback
 */
function gem_app_admin_dashboard() {
    // Get dashboard data from API
    $api = gem_app_api();
    $response = $api->request('/admin/dashboard');
    
    ?>
    <div class="wrap">
        <h1>GEM App Dashboard</h1>
        
        <?php if ($response['success']) : ?>
            <?php $stats = $response['data']['stats']; ?>
            
            <div class="gem-app-stats-grid">
                <div class="gem-app-stat-card">
                    <h2>Total Students</h2>
                    <div class="gem-app-stat-value"><?php echo esc_html($stats['total_students'] ?? 0); ?></div>
                </div>
                
                <div class="gem-app-stat-card">
                    <h2>Matched Students</h2>
                    <div class="gem-app-stat-value"><?php echo esc_html($stats['matched_students'] ?? 0); ?></div>
                </div>
                
                <div class="gem-app-stat-card">
                    <h2>Pending Matches</h2>
                    <div class="gem-app-stat-value"><?php echo esc_html($stats['pending_matches'] ?? 0); ?></div>
                </div>
            </div>
            
            <?php if (!empty($response['data']['final_approval_list'])) : ?>
                <h2>Students Awaiting Final Approval</h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($response['data']['final_approval_list'] as $student) : ?>
                            <tr>
                                <td><?php echo esc_html($student['name']); ?></td>
                                <td><?php echo esc_html($student['status']); ?></td>
                                <td>
                                    <button class="button button-primary gem-app-approve-student" 
                                            data-student-id="<?php echo esc_attr($student['id']); ?>">
                                        Approve
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            
        <?php else : ?>
            <div class="notice notice-error">
                <p>Error fetching dashboard data: <?php echo esc_html($response['message'] ?? 'Unknown error'); ?></p>
            </div>
            
            <p>
                <button class="button button-primary gem-app-authenticate">
                    Authenticate with GEM App
                </button>
            </p>
        <?php endif; ?>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Handle authentication
        $('.gem-app-authenticate').on('click', function(e) {
            e.preventDefault();
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'gem_app_authenticate',
                    nonce: '<?php echo wp_create_nonce('gem-app-nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        window.location.reload();
                    } else {
                        alert('Authentication failed: ' + response.data);
                    }
                }
            });
        });
        
        // Handle student approval
        $('.gem-app-approve-student').on('click', function(e) {
            e.preventDefault();
            
            var studentId = $(this).data('student-id');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'gem_app_approve_student',
                    student_id: studentId,
                    nonce: '<?php echo wp_create_nonce('gem-app-nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        window.location.reload();
                    } else {
                        alert('Approval failed: ' + response.data);
                    }
                }
            });
        });
    });
    </script>
    <?php
}

/**
 * Student Management page callback
 */
function gem_app_admin_students() {
    // Get student data from API
    $api = gem_app_api();
    $response = $api->request('/admin/api/students');
    
    ?>
    <div class="wrap">
        <h1>Student Management</h1>
        
        <?php if ($response['success']) : ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Overall Grade</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($response['data']['students'] as $student) : ?>
                        <tr>
                            <td><?php echo esc_html($student['student_id']); ?></td>
                            <td><?php echo esc_html($student['name']); ?></td>
                            <td><?php echo esc_html($student['status']); ?></td>
                            <td><?php echo esc_html($student['overall_grade'] ?? 'N/A'); ?></td>
                            <td>
                                <a href="?page=gem-app-students&action=view&id=<?php echo esc_attr($student['id']); ?>" 
                                   class="button button-small">
                                    View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <div class="notice notice-error">
                <p>Error fetching student data: <?php echo esc_html($response['message'] ?? 'Unknown error'); ?></p>
            </div>
        <?php endif; ?>
    </div>
    <?php
}
/**
 * Organization Management page callback
 */
function gem_app_admin_organizations() {
    // Get organization data from API
    $api = gem_app_api();
    $response = $api->request('/admin/organizations');
    
    ?>
    <div class="wrap">
        <h1>Organization Management</h1>
        
        <?php if ($response['success']) : ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Area of Law</th>
                        <th>Location</th>
                        <th>Positions</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($response['data']['organizations'] as $org) : ?>
                        <tr>
                            <td><?php echo esc_html($org['id']); ?></td>
                            <td><?php echo esc_html($org['name']); ?></td>
                            <td><?php echo esc_html($org['area_of_law']); ?></td>
                            <td><?php echo esc_html($org['location']); ?></td>
                            <td>
                                <?php echo esc_html($org['filled_positions']); ?> / 
                                <?php echo esc_html($org['available_positions']); ?>
                            </td>
                            <td>
                                <a href="?page=gem-app-organizations&action=view&id=<?php echo esc_attr($org['id']); ?>" 
                                   class="button button-small">
                                    View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <div class="notice notice-error">
                <p>Error fetching organization data: <?php echo esc_html($response['message'] ?? 'Unknown error'); ?></p>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Faculty Management page callback
 */
function gem_app_admin_faculty() {
    $api = gem_app_api();
    $response = $api->request('/admin/faculty');
    
    ?>
    <div class="wrap">
        <h1>Faculty Management</h1>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Positions</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($response['data']['faculty'] as $faculty) : ?>
                    <tr>
                        <td><?php echo esc_html($faculty['id']); ?></td>
                        <td><?php echo esc_html($faculty['name']); ?></td>
                        <td><?php echo esc_html($faculty['department']); ?></td>
                        <td>
                            <?php echo esc_html($faculty['filled_positions']); ?> / 
                            <?php echo esc_html($faculty['available_positions']); ?>
                        </td>
                        <td>
                            <a href="?page=gem-app-faculty&action=view&id=<?php echo esc_attr($faculty['id']); ?>" 
                               class="button button-small">
                                View
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

/**
 * Matching Process page callback
 */
function gem_app_admin_matching() {
    // Get matching data from API
    $api = gem_app_api();
    $response = $api->request('/admin/matching');
    
    ?>
    <div class="wrap">
        <h1>Matching Process</h1>
        
        <?php if ($response['success']) : ?>
            <div class="gem-app-stats-grid">
                <div class="gem-app-stat-card">
                    <h2>Total Students</h2>
                    <div class="gem-app-stat-value"><?php echo esc_html($response['data']['stats']['total_students'] ?? 0); ?></div>
                </div>
                
                <div class="gem-app-stat-card">
                    <h2>Matched Students</h2>
                    <div class="gem-app-stat-value"><?php echo esc_html($response['data']['stats']['matched_students'] ?? 0); ?></div>
                </div>
                
                <div class="gem-app-stat-card">
                    <h2>Unmatched Students</h2>
                    <div class="gem-app-stat-value"><?php echo esc_html($response['data']['stats']['unmatched_students'] ?? 0); ?></div>
                </div>
                
                <div class="gem-app-stat-card">
                    <h2>Available Positions</h2>
                    <div class="gem-app-stat-value"><?php echo esc_html($response['data']['stats']['available_positions'] ?? 0); ?></div>
                </div>
            </div>
            
            <div class="gem-app-matching-actions">
                <button class="button button-primary gem-app-start-matching">
                    Start Matching Process
                </button>
                
                <button class="button gem-app-reset-matches">
                    Reset All Matches
                </button>
            </div>
            
            <h2>Current Matches</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Match ID</th>
                        <th>Student</th>
                        <th>Organization</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($response['data']['matches'] as $match) : ?>
                        <tr>
                            <td><?php echo esc_html($match['match_id']); ?></td>
                            <td><?php echo esc_html($match['student_name']); ?></td>
                            <td><?php echo esc_html($match['organization_name'] ?? 'Unmatched'); ?></td>
                            <td><?php echo esc_html($match['status']); ?></td>
                            <td>
                                <button class="button button-small gem-app-edit-match"
                                        data-match-id="<?php echo esc_attr($match['match_id']); ?>"
                                        data-student-name="<?php echo esc_attr($match['student_name']); ?>"
                                        data-org-name="<?php echo esc_attr($match['organization_name'] ?? ''); ?>">
                                    Edit
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Edit Match Modal -->
            <div id="gem-app-edit-match-modal" class="gem-app-modal" style="display: none;">
                <div class="gem-app-modal-content">
                    <span class="gem-app-modal-close">&times;</span>
                    <h2>Edit Match</h2>
                    
                    <p><strong>Student:</strong> <span id="gem-app-modal-student-name"></span></p>
                    
                    <div class="gem-app-form-group">
                        <label for="gem-app-modal-organization">Organization:</label>
                        <select id="gem-app-modal-organization">
                            <option value="">-- Select Organization --</option>
                            <?php foreach ($response['data']['organizations'] as $org) : ?>
                                <option value="<?php echo esc_attr($org['id']); ?>">
                                    <?php echo esc_html($org['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="gem-app-form-actions">
                        <button class="button button-primary" id="gem-app-modal-save">Save</button>
                        <button class="button" id="gem-app-modal-cancel">Cancel</button>
                    </div>
                </div>
            </div>
            
            <script>
            jQuery(document).ready(function($) {
                // Start matching process
                $('.gem-app-start-matching').on('click', function(e) {
                    e.preventDefault();
                    
                    if (!confirm('Are you sure you want to start the matching process?')) {
                        return;
                    }
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'gem_app_start_matching',
                            nonce: '<?php echo wp_create_nonce('gem-app-nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('Matching process completed successfully.');
                                window.location.reload();
                            } else {
                                alert('Matching process failed: ' + response.data);
                            }
                        }
                    });
                });
                
                // Reset matches
                $('.gem-app-reset-matches').on('click', function(e) {
                    e.preventDefault();
                    
                    if (!confirm('Are you sure you want to reset all matches? This cannot be undone.')) {
                        return;
                    }
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'gem_app_reset_matches',
                            nonce: '<?php echo wp_create_nonce('gem-app-nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('Matches reset successfully.');
                                window.location.reload();
                            } else {
                                alert('Failed to reset matches: ' + response.data);
                            }
                        }
                    });
                });
                
                // Edit match modal
                let currentMatchId = null;
                
                $('.gem-app-edit-match').on('click', function(e) {
                    e.preventDefault();
                    
                    const matchId = $(this).data('match-id');
                    const studentName = $(this).data('student-name');
                    const orgName = $(this).data('org-name');
                    
                    currentMatchId = matchId;
                    
                    $('#gem-app-modal-student-name').text(studentName);
                    
                    // Find and select current organization
                    if (orgName) {
                        $('#gem-app-modal-organization option').each(function() {
                            if ($(this).text() === orgName) {
                                $(this).prop('selected', true);
                                return false;
                            }
                        });
                    } else {
                        $('#gem-app-modal-organization').val('');
                    }
                    
                    $('#gem-app-edit-match-modal').show();
                });
                
                $('.gem-app-modal-close, #gem-app-modal-cancel').on('click', function() {
                    $('#gem-app-edit-match-modal').hide();
                });
                
                $('#gem-app-modal-save').on('click', function() {
                    const orgId = $('#gem-app-modal-organization').val();
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'gem_app_update_match',
                            match_id: currentMatchId,
                            organization_id: orgId,
                            nonce: '<?php echo wp_create_nonce('gem-app-nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                $('#gem-app-edit-match-modal').hide();
                                window.location.reload();
                            } else {
                                alert('Failed to update match: ' + response.data);
                            }
                        }
                    });
                });
            });
            </script>
        <?php else : ?>
            <div class="notice notice-error">
                <p>Error fetching matching data: <?php echo esc_html($response['message'] ?? 'Unknown error'); ?></p>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Grading Interface page callback
 */
function gem_app_admin_grading() {
    // Get grading data from API
    $api = gem_app_api();
    $response = $api->request('/grading/dashboard');
    
    ?>
    <div class="wrap">
        <h1>Grading Interface</h1>
        
        <?php if ($response['success']) : ?>
            <div class="gem-app-stats-grid">
                <div class="gem-app-stat-card">
                    <h2>Total Students</h2>
                    <div class="gem-app-stat-value"><?php echo esc_html($response['data']['stats']['total_students'] ?? 0); ?></div>
                </div>
                
                <div class="gem-app-stat-card">
                    <h2>Average Grade</h2>
                    <div class="gem-app-stat-value"><?php echo esc_html($response['data']['stats']['average_numeric_grade'] ?? 0); ?></div>
                </div>
                
                <div class="gem-app-stat-card">
                    <h2>Ungraded Statements</h2>
                    <div class="gem-app-stat-value"><?php echo esc_html($response['data']['stats']['ungraded_statements'] ?? 0); ?></div>
                </div>
            </div>
            
            <h2>Grade Management</h2>
            <div class="gem-app-grading-tabs">
                <button class="gem-app-grading-tab active" data-tab="grades">Student Grades</button>
                <button class="gem-app-grading-tab" data-tab="statements">Statements</button>
                <button class="gem-app-grading-tab" data-tab="upload">Upload Grades</button>
            </div>
            
            <div class="gem-app-grading-content" id="grades-tab">
                <div class="gem-app-filter-bar">
                    <input type="text" id="student-search" placeholder="Search by name or ID" class="regular-text">
                    <select id="grade-range">
                        <option value="">All Grade Ranges</option>
                        <option value="0-20">0-20</option>
                        <option value="20-30">20-30</option>
                        <option value="30-40">30-40</option>
                    </select>
                    <button class="button" id="apply-filters">Apply Filters</button>
                    <a href="?page=gem-app-grading&action=export-grades" class="button">Export Grades (CSV)</a>
                </div>
                
                <div id="grades-table-container">
                    <!-- Grades table will be loaded here via AJAX -->
                    <p>Loading grades...</p>
                </div>
            </div>
            
            <div class="gem-app-grading-content" id="statements-tab" style="display: none;">
                <div class="gem-app-filter-bar">
                    <select id="statement-filter">
                        <option value="all">All Statements</option>
                        <option value="ungraded">Ungraded Only</option>
                    </select>
                    <button class="button" id="load-statements">Load Statements</button>
                </div>
                
                <div id="statements-table-container">
                    <!-- Statements table will be loaded here via AJAX -->
                    <p>Select filter options and click "Load Statements"</p>
                </div>
            </div>
            
            <div class="gem-app-grading-content" id="upload-tab" style="display: none;">
                <form id="upload-grades-form" enctype="multipart/form-data">
                    <div class="gem-app-form-group">
                        <label for="grade-files">Upload PDF Grade Files:</label>
                        <input type="file" name="files[]" id="grade-files" multiple accept=".pdf">
                        <p class="description">Select one or more PDF grade files to upload.</p>
                    </div>
                    
                    <div class="gem-app-form-actions">
                        <button type="submit" class="button button-primary">Upload and Process</button>
                    </div>
                </form>
                
                <div id="upload-results" style="display: none;">
                    <h3>Upload Results</h3>
                    <div id="upload-results-content"></div>
                </div>
            </div>
            
            <script>
            jQuery(document).ready(function($) {
                // Tab switching
                $('.gem-app-grading-tab').on('click', function() {
                    $('.gem-app-grading-tab').removeClass('active');
                    $(this).addClass('active');
                    
                    const tab = $(this).data('tab');
                    $('.gem-app-grading-content').hide();
                    $(`#${tab}-tab`).show();
                });
                
                // Load grades
                function loadGrades(filters = {}) {
                    $('#grades-table-container').html('<p>Loading grades...</p>');
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'gem_app_filter_grades',
                            filters: filters,
                            nonce: '<?php echo wp_create_nonce('gem-app-nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                if (response.data.students.length === 0) {
                                    $('#grades-table-container').html('<p>No students found matching your criteria.</p>');
                                    return;
                                }
                                
                                let html = '<table class="wp-list-table widefat fixed striped">';
                                html += '<thead><tr>';
                                html += '<th>Student ID</th>';
                                html += '<th>Name</th>';
                                html += '<th>Overall Grade</th>';
                                html += '<th>Grade Breakdown</th>';
                                html += '<th>Upload Date</th>';
                                html += '<th>Actions</th>';
                                html += '</tr></thead>';
                                html += '<tbody>';
                                
                                response.data.students.forEach(function(student) {
                                    html += '<tr>';
                                    html += `<td>${student.student_id || 'N/A'}</td>`;
                                    html += `<td>${student.name}</td>`;
                                    html += `<td>${student.overall_grade || 'N/A'}</td>`;
                                    html += `<td>${student.grade_breakdown || 'N/A'}</td>`;
                                    html += `<td>${student.upload_date || 'N/A'}</td>`;
                                    html += '<td>';
                                    html += `<a href="?page=gem-app-grading&action=view-grades&id=${student.id}" class="button button-small">View</a> `;
                                    html += `<button class="button button-small gem-app-reprocess-grades" data-student-id="${student.id}">Reprocess</button> `;
                                    html += `<button class="button button-small gem-app-delete-grades" data-student-id="${student.id}">Delete</button>`;
                                    html += '</td>';
                                    html += '</tr>';
                                });
                                
                                html += '</tbody></table>';
                                $('#grades-table-container').html(html);
                                
                                // Attach event handlers for reprocess and delete buttons
                                $('.gem-app-reprocess-grades').on('click', function() {
                                    const studentId = $(this).data('student-id');
                                    reprocessGrades(studentId);
                                });
                                
                                $('.gem-app-delete-grades').on('click', function() {
                                    const studentId = $(this).data('student-id');
                                    deleteGrades(studentId);
                                });
                            } else {
                                $('#grades-table-container').html(`<p>Error: ${response.data}</p>`);
                            }
                        }
                    });
                }
                
                // Load grades on page load
                loadGrades();
                
                // Apply filters
                $('#apply-filters').on('click', function() {
                    const search = $('#student-search').val();
                    const gradeRange = $('#grade-range').val();
                    
                    loadGrades({
                        search: search,
                        grade_range: gradeRange
                    });
                });
                
                // Reprocess grades
                function reprocessGrades(studentId) {
                    if (!confirm('Are you sure you want to reprocess grades for this student?')) {
                        return;
                    }
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'gem_app_reprocess_grades',
                            student_id: studentId,
                            nonce: '<?php echo wp_create_nonce('gem-app-nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('Grades reprocessed successfully.');
                                loadGrades();
                            } else {
                                alert('Failed to reprocess grades: ' + response.data);
                            }
                        }
                    });
                }
                
                // Delete grades
                function deleteGrades(studentId) {
                    if (!confirm('Are you sure you want to delete all grades for this student?')) {
                        return;
                    }
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'gem_app_delete_grades',
                            student_id: studentId,
                            nonce: '<?php echo wp_create_nonce('gem-app-nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('Grades deleted successfully.');
                                loadGrades();
                            } else {
                                alert('Failed to delete grades: ' + response.data);
                            }
                        }
                    });
                }
                
                // Load statements
                $('#load-statements').on('click', function() {
                    const filter = $('#statement-filter').val();
                    
                    $('#statements-table-container').html('<p>Loading statements...</p>');
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'gem_app_load_statements',
                            filter: filter,
                            nonce: '<?php echo wp_create_nonce('gem-app-nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                if (response.data.statements.length === 0) {
                                    $('#statements-table-container').html('<p>No statements found.</p>');
                                    return;
                                }
                                
                                let html = '<table class="wp-list-table widefat fixed striped">';
                                html += '<thead><tr>';
                                html += '<th>Student</th>';
                                html += '<th>Area of Law</th>';
                                html += '<th>Preview</th>';
                                html += '<th>Status</th>';
                                html += '<th>Actions</th>';
                                html += '</tr></thead>';
                                html += '<tbody>';
                                
                                response.data.statements.forEach(function(statement) {
                                    html += '<tr>';
                                    html += `<td>${statement.student_name}</td>`;
                                    html += `<td>${statement.area_of_law}</td>`;
                                    html += `<td>${statement.content_preview}</td>`;
                                    html += `<td>${statement.is_graded ? 'Graded' : 'Ungraded'}</td>`;
                                    html += '<td>';
                                    html += `<a href="?page=gem-app-grading&action=grade-statement&id=${statement.id}" class="button button-small">`;
                                    html += statement.is_graded ? 'Edit Grade' : 'Grade';
                                    html += '</a>';
                                    html += '</td>';
                                    html += '</tr>';
                                });
                                
                                html += '</tbody></table>';
                                $('#statements-table-container').html(html);
                            } else {
                                $('#statements-table-container').html(`<p>Error: ${response.data}</p>`);
                            }
                        }
                    });
                });
                
                // Upload grades form
                $('#upload-grades-form').on('submit', function(e) {
                    e.preventDefault();
                    
                    const formData = new FormData(this);
                    formData.append('action', 'gem_app_upload_grades');
                    formData.append('nonce', '<?php echo wp_create_nonce('gem-app-nonce'); ?>');
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(response) {
                            if (response.success) {
                                let html = '<table class="wp-list-table widefat fixed striped">';
                                html += '<thead><tr>';
                                html += '<th>File</th>';
                                html += '<th>Status</th>';
                                html += '<th>Message</th>';
                                html += '</tr></thead>';
                                html += '<tbody>';
                                
                                response.data.processed_files.forEach(function(file) {
                                    html += '<tr>';
                                    html += `<td>${file.filename}</td>`;
                                    html += `<td>${file.success ? 'Success' : 'Error'}</td>`;
                                    html += `<td>${file.message}</td>`;
                                    html += '</tr>';
                                });
                                
                                html += '</tbody></table>';
                                $('#upload-results-content').html(html);
                                $('#upload-results').show();
                                
                                // Reset form
                                $('#upload-grades-form')[0].reset();
                                
                                // Reload grades table
                                loadGrades();
                            } else {
                                alert('Upload failed: ' + response.data);
                            }
                        }
                    });
                });
            });
            </script>
        <?php else : ?>
            <div class="notice notice-error">
                <p>Error fetching grading data: <?php echo esc_html($response['message'] ?? 'Unknown error'); ?></p>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * AJAX handlers for admin actions
 */

// Approve student
function gem_app_ajax_approve_student() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gem-app-nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    // Check if student ID is provided
    if (!isset($_POST['student_id'])) {
        wp_send_json_error('Student ID is required');
    }
    
    // Approve student via API
    $api = gem_app_api();
    $response = $api->request(
        '/admin/final-acceptance/' . intval($_POST['student_id']),
        'POST'
    );
    
    if ($response['success']) {
        wp_send_json_success();
    } else {
        wp_send_json_error($response['message'] ?? 'Failed to approve student');
    }
}
add_action('wp_ajax_gem_app_approve_student', 'gem_app_ajax_approve_student');

// Start matching process
function gem_app_ajax_start_matching() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gem-app-nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    // Start matching via API
    $api = gem_app_api();
    $response = $api->request('/admin/matching/start', 'POST');
    
    if ($response['success']) {
        wp_send_json_success($response['data']);
    } else {
        wp_send_json_error($response['message'] ?? 'Failed to start matching process');
    }
}
add_action('wp_ajax_gem_app_start_matching', 'gem_app_ajax_start_matching');

// Reset matches
function gem_app_ajax_reset_matches() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gem-app-nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    // Reset matches via API
    $api = gem_app_api();
    $response = $api->request('/admin/matching/reset', 'POST');
    
    if ($response['success']) {
        wp_send_json_success();
    } else {
        wp_send_json_error($response['message'] ?? 'Failed to reset matches');
    }
}
add_action('wp_ajax_gem_app_reset_matches', 'gem_app_ajax_reset_matches');

// Update match
function gem_app_ajax_update_match() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gem-app-nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    // Check required parameters
    if (!isset($_POST['match_id'])) {
        wp_send_json_error('Match ID is required');
    }
    
    // Update match via API
    $api = gem_app_api();
    $response = $api->request(
        '/admin/matching/' . intval($_POST['match_id']),
        'PUT',
        array(
            'organization_id' => isset($_POST['organization_id']) ? intval($_POST['organization_id']) : null
        )
    );
    
    if ($response['success']) {
        wp_send_json_success();
    } else {
        wp_send_json_error($response['message'] ?? 'Failed to update match');
    }
}
add_action('wp_ajax_gem_app_update_match', 'gem_app_ajax_update_match');

// Filter grades
function gem_app_ajax_filter_grades() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gem-app-nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    // Get filters
    $filters = isset($_POST['filters']) ? $_POST['filters'] : array();
    
    // Get grades via API
    $api = gem_app_api();
    $response = $api->request('/admin/grades/filter', 'POST', $filters);
    
    if ($response['success']) {
        wp_send_json_success($response['data']);
    } else {
        wp_send_json_error($response['message'] ?? 'Failed to filter grades');
    }
}
add_action('wp_ajax_gem_app_filter_grades', 'gem_app_ajax_filter_grades');

// Reprocess grades
function gem_app_ajax_reprocess_grades() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gem-app-nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    // Check student ID
    if (!isset($_POST['student_id'])) {
        wp_send_json_error('Student ID is required');
    }
    
    // Reprocess grades via API
    $api = gem_app_api();
    $response = $api->request(
        '/admin/grades/' . intval($_POST['student_id']) . '/reprocess',
        'POST'
    );
    
    if ($response['success']) {
        wp_send_json_success();
    } else {
        wp_send_json_error($response['message'] ?? 'Failed to reprocess grades');
    }
}
add_action('wp_ajax_gem_app_reprocess_grades', 'gem_app_ajax_reprocess_grades');

// Delete grades
function gem_app_ajax_delete_grades() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gem-app-nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    // Check student ID
    if (!isset($_POST['student_id'])) {
        wp_send_json_error('Student ID is required');
    }
    
    // Delete grades via API
    $api = gem_app_api();
    $response = $api->request(
        '/admin/grades/' . intval($_POST['student_id']),
        'DELETE'
    );
    
    if ($response['success']) {
        wp_send_json_success();
    } else {
        wp_send_json_error($response['message'] ?? 'Failed to delete grades');
    }
}
add_action('wp_ajax_gem_app_delete_grades', 'gem_app_ajax_delete_grades');

// Load statements
function gem_app_ajax_load_statements() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gem-app-nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    // Get filter
    $filter = isset($_POST['filter']) ? sanitize_text_field($_POST['filter']) : 'all';
    
    // Get statements via API
    $api = gem_app_api();
    $response = $api->request('/grading/statements' . ($filter === 'ungraded' ? '?ungraded=true' : ''));
    
    if ($response['success']) {
        wp_send_json_success($response['data']);
    } else {
        wp_send_json_error($response['message'] ?? 'Failed to load statements');
    }
}
add_action('wp_ajax_gem_app_load_statements', 'gem_app_ajax_load_statements');

// Upload grades
function gem_app_ajax_upload_grades() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gem-app-nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    // Check if files were uploaded
    if (empty($_FILES['files'])) {
        wp_send_json_error('No files uploaded');
    }
    
    // Prepare files for API
    $api = gem_app_api();
    
    // Create a temporary directory for the files
    $temp_dir = wp_upload_dir()['basedir'] . '/gem-app-temp';
    if (!file_exists($temp_dir)) {
        mkdir($temp_dir, 0755, true);
    }
    
    $files_data = array();
    $file_count = count($_FILES['files']['name']);
    
    for ($i = 0; $i < $file_count; $i++) {
        // Skip if there was an upload error
        if ($_FILES['files']['error'][$i] !== UPLOAD_ERR_OK) {
            continue;
        }
        
        $temp_file = $temp_dir . '/' . sanitize_file_name($_FILES['files']['name'][$i]);
        
        // Move the uploaded file to the temporary directory
        if (move_uploaded_file($_FILES['files']['tmp_name'][$i], $temp_file)) {
            $files_data[] = array(
                'name' => $_FILES['files']['name'][$i],
                'path' => $temp_file
            );
        }
    }
    
    // Make API request to upload grades
    $response = $api->request('/admin/upload-grades', 'POST', array(
        'files' => $files_data
    ));
    
    // Clean up temporary files
    foreach ($files_data as $file) {
        if (file_exists($file['path'])) {
            unlink($file['path']);
        }
    }
    
    if ($response['success']) {
        wp_send_json_success($response['data']);
    } else {
        wp_send_json_error($response['message'] ?? 'Failed to upload grades');
    }
}
add_action('wp_ajax_gem_app_upload_grades', 'gem_app_ajax_upload_grades');
