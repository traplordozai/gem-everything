<?php
defined('ABSPATH') || exit;

// Get dashboard data from API
$api = gem_app_get_api();
$response = $api->request('GET', '/admin/dashboard');
$stats = isset($response['data']) ? $response['data'] : array();
?>

<div class="wrap gem-app-dashboard">
    <h1 class="wp-heading-inline">GEM App Dashboard</h1>
    
    <?php if (isset($response['error'])): ?>
        <div class="notice notice-error">
            <p><?php echo esc_html($response['error']); ?></p>
        </div>
    <?php endif; ?>

    <div class="gem-app-stats-grid">
        <div class="gem-app-stat-card">
            <h2>Total Students</h2>
            <div class="gem-app-stat-value"><?php echo esc_html($stats['total_students'] ?? 0); ?></div>
        </div>
        
        <div class="gem-app-stat-card">
            <h2>Active Faculty</h2>
            <div class="gem-app-stat-value"><?php echo esc_html($stats['total_faculty'] ?? 0); ?></div>
        </div>
        
        <div class="gem-app-stat-card">
            <h2>Organizations</h2>
            <div class="gem-app-stat-value"><?php echo esc_html($stats['total_organizations'] ?? 0); ?></div>
        </div>
        
        <div class="gem-app-stat-card">
            <h2>Pending Matches</h2>
            <div class="gem-app-stat-value"><?php echo esc_html($stats['pending_matches'] ?? 0); ?></div>
        </div>
    </div>

    <div class="gem-app-dashboard-sections">
        <div class="gem-app-section">
            <h2>Recent Activity</h2>
            <div class="gem-app-activity-list">
                <?php if (!empty($stats['recent_activity'])): ?>
                    <?php foreach ($stats['recent_activity'] as $activity): ?>
                        <div class="gem-app-activity-item">
                            <span class="activity-type"><?php echo esc_html($activity['type']); ?></span>
                            <span class="activity-description"><?php echo esc_html($activity['description']); ?></span>
                            <span class="activity-time"><?php echo esc_html(human_time_diff(strtotime($activity['timestamp']))); ?> ago</span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No recent activity to display.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="gem-app-section">
            <h2>Quick Actions</h2>
            <div class="gem-app-quick-actions">
                <a href="<?php echo admin_url('admin.php?page=gem-app-students&action=new'); ?>" class="button button-primary">Add New Student</a>
                <a href="<?php echo admin_url('admin.php?page=gem-app-faculty&action=new'); ?>" class="button button-primary">Add New Faculty</a>
                <a href="<?php echo admin_url('admin.php?page=gem-app-organizations&action=new'); ?>" class="button button-primary">Add New Organization</a>
            </div>
        </div>
    </div>
</div>