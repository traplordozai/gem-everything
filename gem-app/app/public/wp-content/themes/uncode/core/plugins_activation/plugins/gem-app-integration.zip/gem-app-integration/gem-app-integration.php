<?php
/**
 * Plugin Name: GEM App Integration
 * Description: Integrates GEM App microservice with WordPress
 * Version: 1.0.0
 * Author: Your Name
 */

defined('ABSPATH') || exit;

// Define plugin constants
define('GEM_APP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('GEM_APP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('GEM_APP_VERSION', '1.0.0');

// Include core files
require_once GEM_APP_PLUGIN_DIR . 'includes/roles/custom-roles.php';
require_once GEM_APP_PLUGIN_DIR . 'includes/admin/class-gem-app-admin.php';
require_once GEM_APP_PLUGIN_DIR . 'includes/admin/class-faculty-calendar.php';
require_once GEM_APP_PLUGIN_DIR . 'includes/admin/class-document-manager.php';
require_once GEM_APP_PLUGIN_DIR . 'includes/admin/class-publication-tracker.php';

class GEM_App_Plugin {
    private static $instance = null;
    private $calendar;
    private $document_manager;
    private $publication_tracker;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
    }

    public function init() {
        // Initialize components
        $this->calendar = new GEM_Faculty_Calendar();
        $this->document_manager = new GEM_Document_Manager();
        $this->publication_tracker = new GEM_Publication_Tracker();
        
        // Initialize admin
        GEM_App_Admin::get_instance()->init();
        
        // Register custom post types and taxonomies
        $this->register_custom_post_types();
        
        // Add menu items
        add_action('admin_menu', array($this, 'add_menu_items'));
    }

    public function activate_plugin() {
        // Initialize roles
        $roles = GEM_App_Roles::get_instance();
        $roles->register_custom_roles();
        
        // Create necessary database tables
        $this->create_database_tables();
        
        // Create required pages
        $this->create_required_pages();
        
        // Set default options
        $this->set_default_options();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }

    private function create_database_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = array();
        
        // Calendar events table
        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}gem_calendar_events (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            description text,
            start_time datetime NOT NULL,
            end_time datetime,
            location varchar(255),
            event_type varchar(50),
            created_by bigint(20),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        // Documents table
        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}gem_documents (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            file_path varchar(255) NOT NULL,
            file_type varchar(50),
            file_size bigint(20),
            uploaded_by bigint(20),
            upload_date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        // Publications table
        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}gem_publications (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            authors text,
            venue varchar(255),
            year int(4),
            publication_type varchar(50),
            citations int(11) DEFAULT 0,
            doi varchar(255),
            created_by bigint(20),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        foreach ($sql as $query) {
            dbDelta($query);
        }
    }

    private function create_required_pages() {
        $pages = array(
            'faculty-dashboard' => array(
                'title' => 'Faculty Dashboard',
                'content' => '[gem_faculty_dashboard]'
            ),
            'calendar' => array(
                'title' => 'Faculty Calendar',
                'content' => '[gem_faculty_calendar]'
            ),
            'documents' => array(
                'title' => 'Document Management',
                'content' => '[gem_document_manager]'
            ),
            'publications' => array(
                'title' => 'Research Publications',
                'content' => '[gem_publication_tracker]'
            )
        );

        foreach ($pages as $slug => $page_data) {
            if (!get_page_by_path($slug)) {
                wp_insert_post(array(
                    'post_title' => $page_data['title'],
                    'post_content' => $page_data['content'],
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'post_name' => $slug
                ));
            }
        }
    }

    private function set_default_options() {
        $defaults = array(
            'gem_app_api_url' => 'http://localhost:5000',
            'gem_app_enable_calendar' => 'yes',
            'gem_app_enable_documents' => 'yes',
            'gem_app_enable_publications' => 'yes',
            'gem_app_document_types' => array('pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'),
            'gem_app_max_upload_size' => '10' // in MB
        );
        
        foreach ($defaults as $key => $value) {
            if (false === get_option($key)) {
                update_option($key, $value);
            }
        }
    }

    public function add_menu_items() {
        add_menu_page(
            'GEM Faculty Portal',
            'Faculty Portal',
            'edit_posts',
            'gem-faculty-portal',
            array($this, 'render_main_page'),
            'dashicons-welcome-learn-more',
            30
        );
        
        add_submenu_page(
            'gem-faculty-portal',
            'Calendar',
            'Calendar',
            'edit_posts',
            'gem-calendar',
            array($this->calendar, 'render_calendar_interface')
        );
        
        add_submenu_page(
            'gem-faculty-portal',
            'Documents',
            'Documents',
            'edit_posts',
            'gem-documents',
            array($this->document_manager, 'render_document_interface')
        );
        
        add_submenu_page(
            'gem-faculty-portal',
            'Publications',
            'Publications',
            'edit_posts',
            'gem-publications',
            array($this->publication_tracker, 'render_publication_interface')
        );
    }

    public function render_main_page() {
        include GEM_APP_PLUGIN_DIR . 'templates/admin/main-page.php';
    }
}

// Initialize the plugin
function GEM_App() {
    return GEM_App_Plugin::get_instance();
}

// Start the plugin
GEM_App();
